//Status code constants for convenience.
module.exports = {
	STATUS_CODE : {
		OK: 200,
		CREATED: 201,
		NO_CONTENT: 204,
		BAD_REQUEST: 400,
		FORBIDDEN: 403,
		NOT_FOUND: 404,
		CONFLICT: 409,
		PRECONDITION_FAILED: 412,
		UNPROCESSABLE : 422,
		LOCKED: 423,
		NOT_FOUND: 404,
		LOCKED: 423,
		ISE: 500
	}
};